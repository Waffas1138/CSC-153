﻿/**
* 4/24/2021
* CSC 153
* Travis Bivins
* This is a redone version of the previous Sales Analysis with the array's being changed into lists
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinUI
{
    public partial class SalesAnaylsisList : Form
    {
        public SalesAnaylsisList()
        {
            InitializeComponent();
        }

        private double GetHighestSales(List<double> sales)
        {

            double outputHighest = sales[0];
            //shifts through the list to find the highest total sales and then stop once it finds it
            for (int index = 1; index < sales.Count; index++)
            {
                if (sales[index] > outputHighest)
                {
                    outputHighest = sales[index];
                }
            }
            // returns the Highest total sales found to the label
            return outputHighest;
        }
        private double GetLowestSales(List<double> sales)
        {
            double outputLowest = sales[0];
            //shifts through the list to find the lowest value and then stop once it finds it
            for (int index = 1; index < sales.Count; index++)
            {
                if (sales[index] < outputLowest)
                {
                    outputLowest = sales[index];
                }
            }
            // returns and displays the lowest sales record to its corresponding label for display
            return outputLowest;
        }
        private double GetAverageSales(List<double> sales)
        {
            
            double total = 0;
            // goes through the list and adding the elements together to get the total amount of values entered
            for (int index = 0; index < sales.Count; index++)
            {
                total += sales[index];
            }
            // divides the total by the length of the array to get the average total sales

            // returns the overall average sales to the label for display
            return total / sales.Count;
        }
        private void getTotalSalesButton_Click(object sender, EventArgs e)
        {
            
            List<double> sales = new List<double>() { 1245.67, 1189.55, 1098.55, 1456.88, 2109.34, 1987.55, 1872.36 };
            // hard coded the total sales list into the program while using the foreach loop to display all the values in the listbox
            foreach (double sale in sales)
            {
                totalSalesListBox.Items.Add(sale);
            }
            // allows you to display the average and highest/lowest total sales while converting to a string so it displays to the user with currenecy formatting
            highestSaleLabel.Text = GetHighestSales(sales).ToString("c");
            lowestSalesLabel.Text = GetLowestSales(sales).ToString("c");
            averageSalesLabel.Text = GetAverageSales(sales).ToString("c");
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // closes the program
            this.Close();
        }
    }
}
