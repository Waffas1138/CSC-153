﻿// Travis Bivins
// CS-153 
// This program will get use an array to pull data from a file that will calculate the total sale value and display when it is run correectly.

using System;
using System.IO;
using System.Windows.Forms;

namespace Total_Sale
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
           try
            {
                string[] allLines = File.ReadAllLines("TotalSales.txt");
                double[] numbers = new double[allLines.Length];
                int counter = 0;
                double sum = 0;

                foreach (string value in allLines)
                {
                    numbers[counter] = Convert.ToDouble(value);
                    sum += numbers[counter];
                    lstOutput.Items.Add(numbers[counter]);
                    counter++;
                }

                lstOutput.Items.Add("\nTotal: " + sum.ToString("n"));
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }
    }
}
