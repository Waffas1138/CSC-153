﻿using System;
using System.IO;
using System.Windows.Forms;

namespace Total_Sales
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string[] allLines = File.ReadAllLines("TotalSale.txt");
                double[] numbers = new double[allLines.Length];
                int counter = 0;
                double sum = 0;

                foreach (string value in allLines)
                {
                    numbers[counter] = Convert.ToDouble(value);
                    sum += numbers[counter];
                    lstOutput.Items.Add(numbers[counter]);
                    counter++;
                }

                lstOutput.Items.Add("\nTotal: " + sum.ToString("n"));
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
