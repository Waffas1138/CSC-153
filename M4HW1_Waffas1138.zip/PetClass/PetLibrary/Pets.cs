﻿/**
 * 3/7/21
 * CSC 153
 * Travis Bivins
 * This program will allow the user to input their pets name, age and type while using a class 
 * object in order to do so in the library.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PetLibrary
{
    public class Pets
    {
        public Pets(string name, string type, int age)
        {
            Name = name;
            Type = type;
            Age = age;
        }
        // This holds the objects needed for the name, type and age without needing a whole mess for it
        // and also allowing it ot be changed whenever and not being predefined 
        public string Name { get; set; }
        public string Type { get; set; }
        public int Age { get; set; }

    }
}
