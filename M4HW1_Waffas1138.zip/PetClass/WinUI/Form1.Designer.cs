﻿
namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.EnterPet = new System.Windows.Forms.Button();
            this.DisplayPet = new System.Windows.Forms.Button();
            this.NameText = new System.Windows.Forms.TextBox();
            this.TypeText = new System.Windows.Forms.TextBox();
            this.AgeText = new System.Windows.Forms.TextBox();
            this.PetOutput = new System.Windows.Forms.ListBox();
            this.PetName = new System.Windows.Forms.Label();
            this.PetAge = new System.Windows.Forms.Label();
            this.PetType = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // EnterPet
            // 
            this.EnterPet.Location = new System.Drawing.Point(54, 226);
            this.EnterPet.Name = "EnterPet";
            this.EnterPet.Size = new System.Drawing.Size(90, 27);
            this.EnterPet.TabIndex = 0;
            this.EnterPet.Text = "Enter Pet Info";
            this.EnterPet.UseVisualStyleBackColor = true;
            this.EnterPet.Click += new System.EventHandler(this.EnterPet_Click);
            // 
            // DisplayPet
            // 
            this.DisplayPet.Location = new System.Drawing.Point(231, 226);
            this.DisplayPet.Name = "DisplayPet";
            this.DisplayPet.Size = new System.Drawing.Size(90, 27);
            this.DisplayPet.TabIndex = 1;
            this.DisplayPet.Text = "Display Pet Info";
            this.DisplayPet.UseVisualStyleBackColor = true;
            this.DisplayPet.Click += new System.EventHandler(this.DisplayPet_Click);
            // 
            // NameText
            // 
            this.NameText.Location = new System.Drawing.Point(199, 44);
            this.NameText.Name = "NameText";
            this.NameText.Size = new System.Drawing.Size(122, 20);
            this.NameText.TabIndex = 2;
            // 
            // TypeText
            // 
            this.TypeText.Location = new System.Drawing.Point(199, 107);
            this.TypeText.Name = "TypeText";
            this.TypeText.Size = new System.Drawing.Size(122, 20);
            this.TypeText.TabIndex = 3;
            // 
            // AgeText
            // 
            this.AgeText.Location = new System.Drawing.Point(199, 176);
            this.AgeText.Name = "AgeText";
            this.AgeText.Size = new System.Drawing.Size(122, 20);
            this.AgeText.TabIndex = 4;
            // 
            // PetOutput
            // 
            this.PetOutput.FormattingEnabled = true;
            this.PetOutput.Location = new System.Drawing.Point(54, 270);
            this.PetOutput.Name = "PetOutput";
            this.PetOutput.Size = new System.Drawing.Size(261, 108);
            this.PetOutput.TabIndex = 5;
            // 
            // PetName
            // 
            this.PetName.AutoSize = true;
            this.PetName.Location = new System.Drawing.Point(51, 47);
            this.PetName.Name = "PetName";
            this.PetName.Size = new System.Drawing.Size(54, 13);
            this.PetName.TabIndex = 6;
            this.PetName.Text = "Pet Name";
            // 
            // PetAge
            // 
            this.PetAge.AutoSize = true;
            this.PetAge.Location = new System.Drawing.Point(51, 183);
            this.PetAge.Name = "PetAge";
            this.PetAge.Size = new System.Drawing.Size(45, 13);
            this.PetAge.TabIndex = 7;
            this.PetAge.Text = "Pet Age";
            // 
            // PetType
            // 
            this.PetType.AutoSize = true;
            this.PetType.Location = new System.Drawing.Point(51, 114);
            this.PetType.Name = "PetType";
            this.PetType.Size = new System.Drawing.Size(50, 13);
            this.PetType.TabIndex = 8;
            this.PetType.Text = "Pet Type";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(399, 422);
            this.Controls.Add(this.PetType);
            this.Controls.Add(this.PetAge);
            this.Controls.Add(this.PetName);
            this.Controls.Add(this.PetOutput);
            this.Controls.Add(this.AgeText);
            this.Controls.Add(this.TypeText);
            this.Controls.Add(this.NameText);
            this.Controls.Add(this.DisplayPet);
            this.Controls.Add(this.EnterPet);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button EnterPet;
        private System.Windows.Forms.Button DisplayPet;
        private System.Windows.Forms.TextBox NameText;
        private System.Windows.Forms.TextBox TypeText;
        private System.Windows.Forms.TextBox AgeText;
        private System.Windows.Forms.ListBox PetOutput;
        private System.Windows.Forms.Label PetName;
        private System.Windows.Forms.Label PetAge;
        private System.Windows.Forms.Label PetType;
    }
}

