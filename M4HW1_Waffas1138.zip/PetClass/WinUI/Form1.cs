﻿/**
 * 3/7/21
 * CSC 153
 * Travis Bivins
 * This program will allow the user to input their pets name, age and type while using a class 
 * object in order to do so in the library.
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PetLibrary;

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        // calling the class and methods from the library
        Pets pets; 
        private void EnterPet_Click(object sender, EventArgs e)
        {
            // This sets the textboxes to the corresponding variables and for the age it presets the value to 0
            // since it isn't a string but still needs a default value
            string name = NameText.Text;
            string type = TypeText.Text;
            int age = 0;


            // This If else command uses the Null or Whitespace command so that way if either of the strings
            // are blank or contain a number it will not process it and will show you the error message to enter a valid input
            if (!string.IsNullOrWhiteSpace(name) && !string.IsNullOrWhiteSpace(type) && int.TryParse(AgeText.Text, out age))
            {
                pets = new Pets(name, type, age);
            }
            else
                MessageBox.Show("Please enter a valid input into the boxes");// error message for when an invlaid input is used
        }

        private void DisplayPet_Click(object sender, EventArgs e)
        {
            try
            {
                PetOutput.Items.Add("Your Pet's name is " + pets.Name + " and your pet is a " + pets.Type);
                // These two are displaying the Name, Typign ang Age of the users pet back to them after entering the data 
                //and hitting display
                PetOutput.Items.Add(" and there age is also " + pets.Age + " year/years old");
            }
            catch (NullReferenceException)
            {
                // another error for if they hit display first instead of entering the data
                MessageBox.Show("Please enter the data first and try again");
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
