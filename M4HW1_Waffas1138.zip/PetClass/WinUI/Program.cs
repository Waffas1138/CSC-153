﻿/**
* 3/7/21
* CSC 153
* Travis Bivins
* This program will allow the user to inpit the name of their animal as well as what type it is like Cat or Dog for example as well as the age
* and it will then create an object and retrieve said object to display back to the user.
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using PetLibrary;

namespace WinUI
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
