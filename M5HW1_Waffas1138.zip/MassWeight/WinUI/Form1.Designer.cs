﻿
namespace WinUI
{
    partial class ClearButton
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.MassText = new System.Windows.Forms.Label();
            this.MassTextbox = new System.Windows.Forms.TextBox();
            this.DisplayWeightButton = new System.Windows.Forms.Button();
            this.ExitButton = new System.Windows.Forms.Button();
            this.Clearbutton2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.WeightLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // MassText
            // 
            this.MassText.AutoSize = true;
            this.MassText.Location = new System.Drawing.Point(157, 76);
            this.MassText.Name = "MassText";
            this.MassText.Size = new System.Drawing.Size(66, 13);
            this.MassText.TabIndex = 0;
            this.MassText.Text = "Enter Mass: ";
            // 
            // MassTextbox
            // 
            this.MassTextbox.Location = new System.Drawing.Point(258, 73);
            this.MassTextbox.Name = "MassTextbox";
            this.MassTextbox.Size = new System.Drawing.Size(149, 20);
            this.MassTextbox.TabIndex = 1;
            // 
            // DisplayWeightButton
            // 
            this.DisplayWeightButton.Location = new System.Drawing.Point(106, 180);
            this.DisplayWeightButton.Name = "DisplayWeightButton";
            this.DisplayWeightButton.Size = new System.Drawing.Size(98, 55);
            this.DisplayWeightButton.TabIndex = 2;
            this.DisplayWeightButton.Text = "Display Weight";
            this.DisplayWeightButton.UseVisualStyleBackColor = true;
            this.DisplayWeightButton.Click += new System.EventHandler(this.DisplayWeightButton_Click);
            // 
            // ExitButton
            // 
            this.ExitButton.Location = new System.Drawing.Point(399, 180);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(98, 55);
            this.ExitButton.TabIndex = 4;
            this.ExitButton.Text = "Exit";
            this.ExitButton.UseVisualStyleBackColor = true;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // Clearbutton2
            // 
            this.Clearbutton2.Location = new System.Drawing.Point(258, 180);
            this.Clearbutton2.Name = "Clearbutton2";
            this.Clearbutton2.Size = new System.Drawing.Size(98, 55);
            this.Clearbutton2.TabIndex = 5;
            this.Clearbutton2.Text = "Clear";
            this.Clearbutton2.UseVisualStyleBackColor = true;
            this.Clearbutton2.Click += new System.EventHandler(this.Clearbutton2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(157, 129);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Weight:";
            // 
            // WeightLabel
            // 
            this.WeightLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.WeightLabel.Location = new System.Drawing.Point(255, 119);
            this.WeightLabel.Name = "WeightLabel";
            this.WeightLabel.Size = new System.Drawing.Size(152, 35);
            this.WeightLabel.TabIndex = 7;
            // 
            // ClearButton
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(608, 307);
            this.Controls.Add(this.WeightLabel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Clearbutton2);
            this.Controls.Add(this.ExitButton);
            this.Controls.Add(this.DisplayWeightButton);
            this.Controls.Add(this.MassTextbox);
            this.Controls.Add(this.MassText);
            this.Name = "ClearButton";
            this.Text = "Exit";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label MassText;
        private System.Windows.Forms.TextBox MassTextbox;
        private System.Windows.Forms.Button DisplayWeightButton;
        private System.Windows.Forms.Button ExitButton;
        private System.Windows.Forms.Button Clearbutton2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label WeightLabel;
    }
}

