﻿/**
* 3/26/21
* CSC 153
* Travis Bivins
* This program will calculate the wight of an object and tell you the user wether it is over, under or is in the right parameters of weight
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinUI
{
    public partial class ClearButton : Form
    {
        public ClearButton()
        {
            InitializeComponent();
        }

        private void DisplayWeightButton_Click(object sender, EventArgs e)
        {
            //Declare the variables as well as sets the textBox to the mass variable and does the math for weight calculations
            double mass, weight;
            mass = double.Parse(MassTextbox.Text);
            weight = mass * 9.8;

            //This if loop will decide and spit out the correct information depending if the users objects mass fits in the criteria listed
            if (weight > 1000)
            {
                WeightLabel.Text = "The object is too heavy";
            }
            else if (weight < 10)
            {
                WeightLabel.Text = "The object is too light";
            }
            else
            {
                WeightLabel.Text = "The object is in the right parameters";
            }
            
        }

        private void Clearbutton2_Click(object sender, EventArgs e)
        {
            //resets the Textboxes back to empty for the user to do another claculation
            MassTextbox.Text = "";
            WeightLabel.Text = "";
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            this.Close(); // Closes the program when clicked
        }
    }
}
