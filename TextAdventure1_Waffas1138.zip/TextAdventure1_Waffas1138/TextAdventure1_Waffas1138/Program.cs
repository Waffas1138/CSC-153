﻿/**
 * 2/7/21
 * Travis Bivins
 * CSC 513
 * This is the main menu for the text adventure program featuring lists and array's
 */


using System;
using System.Collections.Generic;

namespace TextAdventure1_Waffas1138
{
	class Program
	{
		static void Main(string[] args)
		{
			Console.WriteLine("Hello World!");
			bool exit = false;

			//Main menu

			while (exit == false)
			{

				//This display's all the menu options
				//TODO try to enter a short description for each entry in their respective groupings
				Console.WriteLine("1. Display Rooms");
				Console.WriteLine("2. Display Weapon");
				Console.WriteLine("3. Display Potion");
				Console.WriteLine("4. Display Treasure");
				Console.WriteLine("5. Display Items");
				Console.WriteLine("6. Display Mobs");
				Console.WriteLine("7. Exit");
				Console.Write("Enter a choice > ");
				string input = Console.ReadLine();

				if (input == "1")
				{
					string[] rooms = { "Main Hall", "Labratory", "East Wing", "West Wing", "Upper Labs" }; //Here we start coming up with room names to display to the player
					for (int i = 0; i < rooms.Length; i++)
					{
						Console.WriteLine(rooms[i]);
					}
				}
				if (input == "2")
				{
					string[] weapons = { "Super Shotgun", "Mauser", "Rocket Launcher", "Wrist Blades" };// TODO add more weapon variety
					for (int i = 0; i < weapons.Length; i++)
					{
						Console.WriteLine(weapons[i]);
					}
				}
				if (input == "3")
				{
					string[] potions = { "Health Restoration", "Armor Restoration" };// This is for the potions that will be in the game
					for (int i = 0; i < potions.Length; i++)
					{
						Console.WriteLine(potions[i]);
					}
				}
				if (input == "4")
				{
					string[] treasure = { "Super Shotgun upgrade", "Health Orb Chunk", "Gold" };// This will show the player what treasure items they are able to get
					for (int i = 0; i < treasure.Length; i++)
					{
						Console.WriteLine(treasure[i]);
					}
				}
				if (input == "5")
				{
					List<string> itemsList = new List<string>();// Items for the player which for now will just be "ammo" for said player so they have to rotate items
					itemsList.Add("Shotgun Shells");
					itemsList.Add("Pistol Rounds");
					itemsList.Add("Rockets");
					itemsList.Add("Armor Packets");
					for (int index = 0; index < itemsList.Count; index++)
					{
						Console.WriteLine(itemsList[index]);
					}
				}
				if (input == "6")
				{
					List<string> mobsList = new List<string>();//Here is where we will group all of our mobs that you will encounter
					mobsList.Add("Mecha Soldiers");
					mobsList.Add("Grunt");
					mobsList.Add("Heavy Soldier");
					mobsList.Add("Hell Hound");
					mobsList.Add("Imp");
					for (int index = 0; index < mobsList.Count; index++)
					{
						Console.WriteLine(mobsList[index]);
					}
				}
				else if (input == "7")
				{
					exit = true;
				}
				else
				{
					Console.WriteLine("Not a choice!");
				}
			}
		}
	}
}