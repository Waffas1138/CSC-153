﻿/**
* 4/26/2021
* CSC 153
* Travis Bivins
* This program will calculate the Kinetic Energy of an Object after getting the Mass and Velocity from the user and show them the output
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private double KineticEnergy(double mass, double velocity)
        {
            //This is used to calculate the Kintec Energy and uses the Math.Pow command to square the velocity and then returns the Kintec Output for later in the program
            double Kinetic = 0.5 * mass * Math.Pow(velocity,2);
            return Kinetic;
        }
        private void ConvertToKinetic_Click(object sender, EventArgs e)
        {
            double mass, velocity;
            // sets up the TryParse command to make sure the user inputs the correct values and not letters for example
            if (double.TryParse(MassTextBox.Text, out mass) && double.TryParse(VelocityTextBox.Text, out velocity))
            {
                // calls the Kinetic varaible back into the main method by calling the Kinetic Energy method and the variables within it and then pushing the output
                // innto the textbox and converting it to a string so it displays within the textbod with no problems and then converts it to numbers so it will have the comma's and decimal places
                double Kinetic = KineticEnergy(mass, velocity);
                KineticEnergyOutput.Text = Kinetic.ToString("n");
            }
            else
                // This is the error message if the user fails the try prase and enters the wrong values
                MessageBox.Show("That was an Invalid Input please try again with the correct inputs.");
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            // Closes the program when clicked
            this.Close();
        }
    }
}
