﻿namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.MassLabel = new System.Windows.Forms.Label();
            this.VelocityLabel = new System.Windows.Forms.Label();
            this.ObjectKinetic = new System.Windows.Forms.Label();
            this.KineticEnergyOutput = new System.Windows.Forms.Label();
            this.MassTextBox = new System.Windows.Forms.TextBox();
            this.VelocityTextBox = new System.Windows.Forms.TextBox();
            this.ConvertToKinetic = new System.Windows.Forms.Button();
            this.ExitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // MassLabel
            // 
            this.MassLabel.AutoSize = true;
            this.MassLabel.Location = new System.Drawing.Point(30, 43);
            this.MassLabel.Name = "MassLabel";
            this.MassLabel.Size = new System.Drawing.Size(73, 13);
            this.MassLabel.TabIndex = 0;
            this.MassLabel.Text = "Object\'s Mass";
            // 
            // VelocityLabel
            // 
            this.VelocityLabel.AutoSize = true;
            this.VelocityLabel.Location = new System.Drawing.Point(30, 81);
            this.VelocityLabel.Name = "VelocityLabel";
            this.VelocityLabel.Size = new System.Drawing.Size(85, 13);
            this.VelocityLabel.TabIndex = 1;
            this.VelocityLabel.Text = "Object\'s Velocity";
            // 
            // ObjectKinetic
            // 
            this.ObjectKinetic.AutoSize = true;
            this.ObjectKinetic.Location = new System.Drawing.Point(30, 119);
            this.ObjectKinetic.Name = "ObjectKinetic";
            this.ObjectKinetic.Size = new System.Drawing.Size(114, 13);
            this.ObjectKinetic.TabIndex = 2;
            this.ObjectKinetic.Text = "Objects Kinetic Energy";
            // 
            // KineticEnergyOutput
            // 
            this.KineticEnergyOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.KineticEnergyOutput.Location = new System.Drawing.Point(192, 118);
            this.KineticEnergyOutput.Name = "KineticEnergyOutput";
            this.KineticEnergyOutput.Size = new System.Drawing.Size(121, 13);
            this.KineticEnergyOutput.TabIndex = 3;
            // 
            // MassTextBox
            // 
            this.MassTextBox.Location = new System.Drawing.Point(192, 40);
            this.MassTextBox.Name = "MassTextBox";
            this.MassTextBox.Size = new System.Drawing.Size(121, 20);
            this.MassTextBox.TabIndex = 4;
            // 
            // VelocityTextBox
            // 
            this.VelocityTextBox.Location = new System.Drawing.Point(192, 78);
            this.VelocityTextBox.Name = "VelocityTextBox";
            this.VelocityTextBox.Size = new System.Drawing.Size(121, 20);
            this.VelocityTextBox.TabIndex = 5;
            // 
            // ConvertToKinetic
            // 
            this.ConvertToKinetic.Location = new System.Drawing.Point(49, 164);
            this.ConvertToKinetic.Name = "ConvertToKinetic";
            this.ConvertToKinetic.Size = new System.Drawing.Size(95, 36);
            this.ConvertToKinetic.TabIndex = 6;
            this.ConvertToKinetic.Text = "Convert to Kinetic Energy";
            this.ConvertToKinetic.UseVisualStyleBackColor = true;
            this.ConvertToKinetic.Click += new System.EventHandler(this.ConvertToKinetic_Click);
            // 
            // ExitButton
            // 
            this.ExitButton.Location = new System.Drawing.Point(192, 164);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(121, 36);
            this.ExitButton.TabIndex = 7;
            this.ExitButton.Text = "Exit";
            this.ExitButton.UseVisualStyleBackColor = true;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(382, 226);
            this.Controls.Add(this.ExitButton);
            this.Controls.Add(this.ConvertToKinetic);
            this.Controls.Add(this.VelocityTextBox);
            this.Controls.Add(this.MassTextBox);
            this.Controls.Add(this.KineticEnergyOutput);
            this.Controls.Add(this.ObjectKinetic);
            this.Controls.Add(this.VelocityLabel);
            this.Controls.Add(this.MassLabel);
            this.Name = "Form1";
            this.Text = "Kinetic Energy";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label MassLabel;
        private System.Windows.Forms.Label VelocityLabel;
        private System.Windows.Forms.Label ObjectKinetic;
        private System.Windows.Forms.Label KineticEnergyOutput;
        private System.Windows.Forms.TextBox MassTextBox;
        private System.Windows.Forms.TextBox VelocityTextBox;
        private System.Windows.Forms.Button ConvertToKinetic;
        private System.Windows.Forms.Button ExitButton;
    }
}

