﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library
{
    public static class World
    {
        public static bool exit = false;
        public static int index = 0;
        // This keeps all of the lists used in the game as well as set our room to the staring location to get us squared away.
        public static List<string> rooms = new List<string>() { "East wing", "Library", "Main Hall", "Upper Labs", "West Wing" };
        public static List<string> weapons = new List<string>() { "Super Shotgun", "Mauser", "Rocket Launcher", "Wrist Blades" };
        public static List<string> potions = new List<string>() { "Health Restoration", "Armor Restoration" };
        public static List<string> treasures = new List<string>() { "Super Shotgun upgrade", "Health Orb Chunk", "Gold" };
        public static List<string> items = new List<string>() { "Red Key", "Pin", "Case", "Rod" };
        public static List<string> mobs = new List<string>() { "Mecha Soldiers", "Grunt", "Heavy Soldier", "Hell Hound", "Imp" };
    }

}
