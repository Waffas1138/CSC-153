﻿// Travis Bivins
// 4/12/21
// CSC 153
// Program that will display the Highest, Lowest and Average test scores to the user as well as displaying all the test scores as well in a seperate listbox from the labels.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Test_Average
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        
        private int GetHighestScore(int[] inputArray)
        {
            int outputHighest = inputArray[0];
            //shifts through the array to find the highest value and then stop once it finds it
            for (int index = 1; index < inputArray.Length; index++)
            {
                if(inputArray[index] > outputHighest)
                {
                    outputHighest = inputArray[index];
                }
            }
            // returns the Highest score found to the label
            return outputHighest;
        }
        
        private double GetAverageScore(int[] inputArray)
        {
            double outputAverage = 0;
            int total = 0;
            // goes through the array and adding the elements together to get the total
            for (int index = 0; index < inputArray.Length; index++)
            {
                total += inputArray[index];
            }
            // divides the total by the length of the array to get the average
            outputAverage = total / inputArray.Length;
            // returns the overall average to the label for display
            return outputAverage;
        }
        
        private int GetLowestScore(int[] inputArray)
        {
            int outputLowest = inputArray[0];
            //shifts through the array to find the lowest value and then stop once it finds it
            for( int index =1; index < inputArray.Length; index++)
            {
                if(inputArray[index] < outputLowest)
                {
                    outputLowest = inputArray[index];
                }
            }
            // returns and displays the lowest score to its corresponding label for display
            return outputLowest;
        }
        private void getScoresButton_Click(object sender, EventArgs e)
        {
            int[] scores = { 70, 65, 88, 100, 90 };
            // hard coded array into the program while using the foreach loop to display all the values in the listbox
            foreach (int score in scores)
            {
                testScoresListBox.Items.Add(score);
            }
            // allows you to display the average and highest/lowest score whilee converting to a string so it displays to the user
            highScoreLabel.Text = GetHighestScore(scores).ToString();
            lowScoreLabel.Text = GetLowestScore(scores).ToString();
            averageScoreLabel.Text = GetAverageScore(scores).ToString();
        }
        private void exitButton_Click(object sender, EventArgs e)
        {
            // closes the program
            this.Close();
        }
    }
}
