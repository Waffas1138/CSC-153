﻿/**
* 4/26/21
* CSC 153
* Travis Bivins
* This program will convert cups to ounces based upon the users input and also adding 10 to the value at the end of it.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cups_To_Ounces
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void convertButton_Click(object sender, EventArgs e)
        {
            double cups, ounces;
            // Try parse statement to make sure the user can only input a number into the box and if they enter an invalid option
            // it will then give the user an error message if they attempt to do so.
            if(double.TryParse(cupsTextBox.Text, out cups))
            {
              
                ounces = Cups_To_Ounces(cups);
                AddTen(ref ounces);
                ouncesLabel.Text = ounces.ToString("n1");
            }
            else
            {
                // This is the error message if they fail the try parse.
                MessageBox.Show("Enter a valid number!");
            }
        }

        private void AddTen(ref double ounces)
        {
            // adds 10 to the ounces at the end of the calculation
            ounces += 10;
        }

        private double Cups_To_Ounces(double cups)
        {
            // returns the cup values after being multiplied by 8 for the ounces
            return cups * 8.0;
        }

        
        private void exitButton_Click(object sender, EventArgs e)
        {
            // Closes the program when clicked on
            this.Close();
        }
    }
}
