﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinUI
{
    class CellPhone
    {
        // This is the constructor for the method
        public CellPhone()
        {
            Brand = "";
            Model = "";
            Price = 0m;
        }


        //Properties for Brand, Model and Price 
        public string Brand { get; set; }
        public string Model { get; set; }
        public decimal Price { get; set; }
    }
}
