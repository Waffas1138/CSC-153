﻿/**
* 5/3/2021
* CSC 153
* Travis Bivins
* This program lets the user input multiple phones with the brand, model and price to then view in a list format
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinUI
{
    public partial class Form1 : Form
     {
        //Creates the list that will hold the objects
        List<CellPhone> phoneList = new List<CellPhone>();
        public Form1()
        {
          InitializeComponent();
        }

        private void GetPhoneData(CellPhone phone)
        {
            decimal price; 
            //Sets the price, brand and model textboxes to be used and 
            //allow the user to input the values
            phone.Brand = brandTextBox.Text;
            phone.Model = modelTextBox.Text;

            //Try parse so if the user does not input a correct value for the price
            // it will spit out the error messages for them
            if(decimal.TryParse(priceTextBox.Text, out price))
            {
                phone.Price = price;
            }
            else
            {
                MessageBox.Show("Please enter a valid price.");
            }
        }

         private void addPhoneButton_Click(object sender, EventArgs e)
         {
            //Sets everything up in place and makes sure the inputs match the correct fields they need
            CellPhone myPhone = new CellPhone();

            GetPhoneData(myPhone);

            phoneList.Add(myPhone);

            phoneListBox.Items.Add(myPhone.Brand + " " + myPhone.Model);

            //Clears the textboxes after they are input into the list so the next value can be put in
            brandTextBox.Clear();
            modelTextBox.Clear();
            priceTextBox.Clear();
            //automatically puts the user back to the Brand textbox
            brandTextBox.Focus();

         }

        private void phoneListBox_SelectedIndexChanged(object sender, EventArgs e)
         {
            //Creates the index so the list box can go for as long as the user needs it to be and also sets the price
            // to currenecy format
            int index = phoneListBox.SelectedIndex;
            MessageBox.Show(phoneList[index].Price.ToString("c"));  
         }

         private void exitButton_Click(object sender, EventArgs e)
         {
             //Closes the program
            this.Close();
         }
    }
    
}
