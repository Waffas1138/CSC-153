﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace RoomIndex
{
    public class Rooms
    {
       public static void roomIndex()
       {
            var random = new Random();
            var list = new List<string> { "East wing", "Labratory", "Main Hall", "Upper Labs", "West Wing" };
            int index = random.Next(list.Count);
            Console.WriteLine("You are currently in " + list[index]);
            //Will change this after talking with you, as of right now this randomly chooses your room for you and where you will be at
            // but will fix it in order to function the north and south commands


        }
    }
}

