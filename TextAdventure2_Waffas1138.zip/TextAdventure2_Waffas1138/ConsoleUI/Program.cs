﻿/**
 * 2/28/21
 * Travis Bivins
 * CSC 513
 * This is the main menu for the text adventure program featuring lists and array's 
 * with a revised menu and display for rooms/weapons
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RoomIndex; // Using RoomIndex class to grab the rooms and random starting room, will be fixed later
using AttackIndex; // Using AttackIndex class in order to do random amounts of damage from 1-20

namespace ConsoleUI
{
   public class Program
    {
		public static void Main(string[] args)
		{
			Console.WriteLine("Hello and welcome!");
			bool exit = false;

			//Main menu

			while (exit == false)
			{

				//This display's the revised menu options that have been changed

				Console.WriteLine("1. Move North");
				Console.WriteLine("2. Move South");
				Console.WriteLine("3. Attack");
				Console.WriteLine("4. Exit");
				Console.WriteLine("______________");
				Console.Write("Enter a choice > ");
				

				string input = Console.ReadLine();

                if (input == "1") 
				{
					Rooms.roomIndex(); //Got rid of the previous statement and moved it all to a different class that randomly picks the room you are in
				}
				if (input == "2")
				{
					Rooms.roomIndex();//Got rid of the previous statement and moved it all to a different class that randomly picks the room you are in
				}
			
				if (input == "3")
				{
                    int attack = 0;
                    Attack.attack(attack); // Calls the random attack method from the attack class for damage values
				}
				else if (input == "4")
				{
					exit = true; // still exits the game
				}

				else
				{
					Console.WriteLine("Not a choice!");
				}


			}
		}
	}
}
