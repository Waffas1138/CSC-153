﻿using System;

public class Class1
{
	public Class1()
	{
		static void roomIndex()
        {
            string[] rooms = { "East wing", "Labratory", " Main Hall", "Upper Labs", "West Wing" };
            switch (input.ToLower())
            {
                case "room":
                    foreach (string room in rooms)
                    {
                        Console.WriteLine(room);
                    }
                    break;
                case "north":
                    room++;
                    break;
                case "south":
                    room--;
                    break;
                if(room >= 4)
                    {
                        Console.WriteLine("No more rooms north");
                    }
                    else
                    {
                        room--;
                    }
                    if (room <= 0)
                    {
                        Console.WriteLine("No more rooms south");

                    }
                    else
                    {
                        room--
                    }
            }
            
        }
}
