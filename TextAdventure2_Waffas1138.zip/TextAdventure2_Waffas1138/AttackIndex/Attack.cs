﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AttackIndex
{
    public class Attack
    {
        public static void attack(int atk)
        {
            Random random = new Random();
            int attack = random.Next(1, 20);
            //This litte command is what will give us our randomly generated damage value that the player has dealt
            Console.WriteLine("You have hit the enemy for a total of " + attack + " damage"); 
            
        }
    }
}
