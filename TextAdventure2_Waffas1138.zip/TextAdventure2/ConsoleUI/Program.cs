﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Library;

namespace ConsoleUI
{
	class Program
	{
		static void Main(string[] args)
		{
			Console.WriteLine("Hello and welcome!");
			bool exit = false;

            //Main menu
            int roomIndex = 0;
            while (exit == false)
			{
                string[] rooms = { "East wing", "Labratory", "Main Hall", "Upper Labs", "West Wing" };
				
				//This display's the revised menu options that have been changed

				Console.WriteLine("You are now in " + rooms[roomIndex]);
                Console.WriteLine("1. Move North");
				Console.WriteLine("2. Move South");
				Console.WriteLine("3. Attack");
				Console.WriteLine("4. Exit");
				Console.WriteLine("______________");
				Console.Write("Enter a choice > ");
				

				string input = Console.ReadLine();

                if (input == "north") 
				{
                    roomIndex++;
                 //Got rid of the previous statement and moved it all to a different class that randomly picks the room you are in
                   
				}
				else if (input == "south")
				{
					roomIndex--;//Got rid of the previous statement and moved it all to a different class that randomly picks the room you are in
				}
			
				else if (input == "attack")
				{
					int attack = 0;
                    MainLibrary.attack(attack);
				}
				else if (input == "exit")
				{
					exit = true; // still exits the game
				}
				else if (input == "weapons")
				{

                    string weapons = null;
                    MainLibrary.gear(weapons);
				}
				else if (input == "potions")
				{
					string potions = null;
					MainLibrary.potions(potions);
				}
				else if (input == "treasure")
				{
					string treasure = null;
					MainLibrary.treasures(treasure);
				}
				else if (input == "items")
				{
					string items = null;
					MainLibrary.items(items);
				}
				else if (input == "mobs")
				{
					string mobs = null;
					MainLibrary.mobs(mobs);
				}
				
				else
				{
					Console.WriteLine("Not a choice!");
				}
			}
		}
	}
}
