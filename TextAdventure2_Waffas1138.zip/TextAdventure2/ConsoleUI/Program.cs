﻿
/**
* 2/28/2021
* CSC 153
* Travis Bivins
* Revised version of the menu or the text based adventure with features to traverse North or south as well as search for items, weapons, treasure, mobs and potions just by typing them into the command prompt without
* needing a menu navigation for them
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Library;

namespace ConsoleUI
{
	class Program
	{
		static void Main(string[] args)
		{
			Console.WriteLine("Hello and welcome!");
			bool exit = false;

            //Main menu
            int roomIndex = 0;
            while (exit == false)
			{
                string[] rooms = { "East wing", "Labratory", "Main Hall", "Upper Labs", "West Wing" };
				
				//This display's the revised menu options that have been changed

				Console.WriteLine("You are now in " + rooms[roomIndex]);
                Console.WriteLine("1. Move North");
				Console.WriteLine("2. Move South");
				Console.WriteLine("3. Attack");
				Console.WriteLine("4. Exit");
				Console.WriteLine("______________");
				Console.Write("Enter a choice > ");
				

				string input = Console.ReadLine();

				if (input == "north")
				{
					roomIndex++;// If the user goes North then the program will advance the user up one room and let them know where they are currently at


				}
				else if (input == "south")
				{
					roomIndex--;// If the user goes South then the program will advance the user down one room and let them know where they are currently at
				}

				else if (input == "attack")
				{
					int attack = 0;
					MainLibrary.attack(attack);// randomly generates the attack damage that the user has dealt
				}
				else if (input == "exit")
				{
					exit = true; // still exits the game
				}
				else if (input == "weapons")
				{

					string weapons = null;
					MainLibrary.gear(weapons);//Pulls the weapon log from the main library
				}
				else if (input == "potions")
				{
					string potions = null;
					MainLibrary.potions(potions);//Pulls the potion log from the main library
				}
				else if (input == "treasure")
				{
					string treasure = null;
					MainLibrary.treasures(treasure);//Pulls the treasure log from the main library
				}
				else if (input == "items")
				{
					string items = null;
					MainLibrary.items(items);//Pulls the items log from the main library
				}
				else if (input == "mobs")
				{
					string mobs = null;
					MainLibrary.mobs(mobs);//Pulls the mobs log from the main library
				}

				else
				{
					Console.WriteLine("Not a choice!");// shows up if they user entered an invalid choice
				}
			}
		}
	}
}
