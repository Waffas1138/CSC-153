﻿/**
* Date
* CSC 153
* Name
* Program description
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library
{
    public class MainLibrary
    {
        public static void attack(int atk)
        {
            Random random = new Random();
            int attack = random.Next(1, 20);
            //This litte command is what will give us our randomly generated damage value that the player has dealt
            Console.WriteLine("You have hit the enemy for a total of " + attack + " damage");
        }
        public static void gear(string weapons)
        {
            string[] weapon = { "Super Shotgun", "Mauser", "Rocket Launcher", "Wrist Blades" };// add more weapon variety later
            for (int i = 0; i < weapon.Length; i++)
            {
                Console.WriteLine(weapon[i]);
            }
        }
        public static void items(string item)
        {
            List<string> itemsList = new List<string>();// Items for the player which for now will just be "ammo" for said player so they have to rotate items
            itemsList.Add("Armor Packets");
            itemsList.Add("Pistol Rounds");
            itemsList.Add("Rockets");
            itemsList.Add("Shotgun Shells");
            for (int index = 0; index < itemsList.Count; index++)
            {
                Console.WriteLine(itemsList[index]);
            }
        }
        public static void potions(string potion)
        {
            string[] potions = { "Health Restoration", "Armor Restoration" };// This is for the potions that will be in the game
            for (int i = 0; i < potions.Length; i++)
            {
                Console.WriteLine(potions[i]);
            }
        }
        public static void treasures(string treasure)
        {
            string[] treasures = { "Super Shotgun upgrade", "Health Orb Chunk", "Gold" };// This will show the player what treasure items they are able to get
            for (int i = 0; i < treasures.Length; i++)
            {
                Console.WriteLine(treasures[i]);
            }
        }
        public static void mobs(string mobs)
        {
            List<string> mobsList = new List<string>();//Here is where we will group all of our mobs that you will encounter
            mobsList.Add("Mecha Soldiers");
            mobsList.Add("Grunt");
            mobsList.Add("Heavy Soldier");
            mobsList.Add("Hell Hound");
            mobsList.Add("Imp");
            for (int index = 0; index < mobsList.Count; index++)
            {
                Console.WriteLine(mobsList[index]);
            }
        }
    }
}
