﻿/**
* 2/18/2021
* CSC 153
* Travis Bivins
* This will be using the formula to calculate the distance an object has fallen after 
* recieving user input from it.
*/
using System;

namespace M3HW2_Waffas1138
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("How many seconds has your object been falling?: ");
            // This Converts the string into an int to be used for calculations 
            int time = Convert.ToInt32(Console.ReadLine());
            // This is returning the method down below to be used now.
            FallingDistance(time);
        }
        
        // Method containing the caluclations for distance and using the time variable from above in it
        static void FallingDistance(int time)
        {

            // Calculates the distance the users item has gone as well spits out the sentence 
            // showing them how far it has traveled
            double distance = 0.5 * 9.8 * Math.Pow(time, 2);
           Console.WriteLine("The distance traveled is:" + distance);
            Console.ReadLine();
        }
    }
}
