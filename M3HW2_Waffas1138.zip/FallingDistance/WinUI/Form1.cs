﻿/**
 * 2/22/2021
 * CSC 153
 * Travis Bivins
 * Program will use the distance formula to calculate how far the object will have traveld after the user inputs how many seconds
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FallingDistanceLibrary;

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public void StartButton_Click(object sender, EventArgs e)//This section is the code for what happens the button is pressed allowing the user to see their distance
        {
            double time;
            
            if (double.TryParse(dropText.Text, out time))
            {
                double distance = FallingCalc.FallingDistance(time);//Calls the Distance formula from the FallingCalc class in my other library
                DistanceText.Text = distance.ToString("n") + " meters"; // changes it to a string and number format as well as showwing meters at the end for travel distance
            }
            else
                MessageBox.Show("Please enter time in seconds"); // error incase they enter something that is not a number
        }
        
        private void ExitButton_Click(object sender, EventArgs e)
        {
            this.Close(); // very simple command that closes the program when clicked
        }
    }
}
