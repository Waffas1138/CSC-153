﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
// Seperate library used for calculating the distance formula for the object
namespace FallingDistanceLibrary
{
    public class FallingCalc
    {
        public void double FallingDistance(double time)
        {
            double distance = 0.5 * 9.8 * Math.Pow(time, 2);
            return distance; // returns the answer when called in the main thing
        }
    }
}
