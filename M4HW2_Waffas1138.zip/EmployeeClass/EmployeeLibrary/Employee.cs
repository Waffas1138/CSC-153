﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLibrary
{
    public class Employee
    {

        // the _ followed by the string values allow it to be overloaded for future use and start
        // the constructors
        public string _Name;
        public string _IdNumber;
        public string _Department;
        public string _Position;


        public Employee(string Name, string IdNumber, string Department, string position)
        {
            _Name = Name;
            _IdNumber = IdNumber;
            _Department = Department;
            _Position = position;
        }

        // This section is used to set the methods and class for each of the strings that'll allow me to
        // overload it and force put in the values needed
        public string Name
        {
            get { return _Name; }
            set { _Name = value; }
        }
        public string IdNumber
        {
            get { return _IdNumber; }
            set { _IdNumber = value; }
        }
        public string Department
        {
            get { return _Department; }
            set { _Department = value; }
        }
        public string Position
        {
            get { return _Position; }
            set { _Position = value; }
        }
    }
}
