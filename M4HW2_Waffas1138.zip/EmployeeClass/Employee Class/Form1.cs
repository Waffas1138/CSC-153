﻿/**
* 3/21/21
* CSC 153
* Travis Bivins
* This porgram will have another class in it that holds an employees name, IdNumber, Department and Position
* while also using overloaded constructors to pass hard coded values in for three employees herer
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EmployeeLibrary;// the second class that holds the get sets and returns.


namespace Employee_Class
{
    public partial class emplyee : Form
    {
        

        public emplyee()
        {
            InitializeComponent();
        }
        Employee employee;
        //This calls the Employee class and allows me to hard code in the employee values for the three below me
        Employee empl1 = new Employee("Susan Meyers", "47899", "Accounting", "Vice President");
        Employee empl2 = new Employee("Mark Jones", "39119", "IT", "Programmer");
        Employee empl3 = new Employee("Joy Rogers", "81774", "Manufacturing", "Engineer");
        
        private void DisplayButton_Click(object sender, EventArgs e)
        {

            //adds the employees into the listbox as well sending the hard coded values in here as well
            EmpOut.Items.Add("Employee 1:" + empl1.Name + " " + empl1.IdNumber + " " + empl1.Department +  " " + empl1.Position);
            EmpOut.Items.Add("Employee 2:" + empl2.Name + " " + empl2.IdNumber + " " + empl2.Department + " " + empl2.Position);
            EmpOut.Items.Add("Employee 3:" + empl3.Name + " " + empl3.IdNumber + " " + empl3.Department + " " + empl3.Position);
        }
       
        

        private void ExitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        
    }
}
