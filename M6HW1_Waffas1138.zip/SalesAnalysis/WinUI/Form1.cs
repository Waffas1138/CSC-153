﻿/**
* 4/17/21
* CSC 153
* Travis Bivins
* This program uses a hard coded array to depict the total sales earned and then uses said array and loops to find the highest, lowest and the average total sale values to then return to the user to see for themselves
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private double GetHighestSales(double[] inputArray)
        {
            double outputHighest = inputArray[0];
            //shifts through the array to find the highest total sales and then stop once it finds it
            for (int index = 1; index < inputArray.Length; index++)
            {
                if (inputArray[index] > outputHighest)
                {
                    outputHighest = inputArray[index];
                }
            }
            // returns the Highest total sales found to the label
            return outputHighest;
        }

        private double GetAverageSales(double[] inputArray)
        {
            double outputAverage = 0;
            double total = 0;
            // goes through the array and adding the elements together to get the total amount of values entered
            for (int index = 0; index < inputArray.Length; index++)
            {
                total += inputArray[index];
            }
            // divides the total by the length of the array to get the average total sales
            outputAverage = total / inputArray.Length;
            // returns the overall average sales to the label for display
            return outputAverage;
        }

        private double GetLowestSales(double[] inputArray)
        {
            double outputLowest = inputArray[0];
            //shifts through the array to find the lowest value and then stop once it finds it
            for (int index = 1; index < inputArray.Length; index++)
            {
                if (inputArray[index] < outputLowest)
                {
                    outputLowest = inputArray[index];
                }
            }
            // returns and displays the lowest sales record to its corresponding label for display
            return outputLowest;
        }
        private void getTotalSalesButton_Click(object sender, EventArgs e)
        {
            double[] sales = { 1245.67, 1189.55, 1098.55, 1456.88, 2109.34, 1987.55, 1872.36 };
            
            // hard coded the total sales array into the program while using the foreach loop to display all the values in the listbox
            foreach (double sale in sales)
            {
                totalSalesListBox.Items.Add(sale);
            }
            // allows you to display the average and highest/lowest total sales while converting to a string so it displays to the user with currenecy formatting
            highestSaleLabel.Text = GetHighestSales(sales).ToString("c");
            lowestSalesLabel.Text = GetLowestSales(sales).ToString("c");
            averageSalesLabel.Text = GetAverageSales(sales).ToString("c");
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // closes the program
            this.Close();
        }
    }
}
