﻿
namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.testScoresDescriptionLabel = new System.Windows.Forms.Label();
            this.totalSalesListBox = new System.Windows.Forms.ListBox();
            this.getTotalSalesButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.highestSaleDescriptionLabel = new System.Windows.Forms.Label();
            this.lowestSalesDescriptionLabel = new System.Windows.Forms.Label();
            this.averageSalesDescriptionLabel = new System.Windows.Forms.Label();
            this.highestSaleLabel = new System.Windows.Forms.Label();
            this.lowestSalesLabel = new System.Windows.Forms.Label();
            this.averageSalesLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // testScoresDescriptionLabel
            // 
            this.testScoresDescriptionLabel.AutoSize = true;
            this.testScoresDescriptionLabel.Location = new System.Drawing.Point(12, 9);
            this.testScoresDescriptionLabel.Name = "testScoresDescriptionLabel";
            this.testScoresDescriptionLabel.Size = new System.Drawing.Size(58, 13);
            this.testScoresDescriptionLabel.TabIndex = 6;
            this.testScoresDescriptionLabel.Text = "Total sales";
            // 
            // totalSalesListBox
            // 
            this.totalSalesListBox.FormattingEnabled = true;
            this.totalSalesListBox.Location = new System.Drawing.Point(12, 36);
            this.totalSalesListBox.Name = "totalSalesListBox";
            this.totalSalesListBox.Size = new System.Drawing.Size(120, 95);
            this.totalSalesListBox.TabIndex = 7;
            // 
            // getTotalSalesButton
            // 
            this.getTotalSalesButton.Location = new System.Drawing.Point(63, 175);
            this.getTotalSalesButton.Name = "getTotalSalesButton";
            this.getTotalSalesButton.Size = new System.Drawing.Size(130, 23);
            this.getTotalSalesButton.TabIndex = 14;
            this.getTotalSalesButton.Text = "Get Total Sales";
            this.getTotalSalesButton.UseVisualStyleBackColor = true;
            this.getTotalSalesButton.Click += new System.EventHandler(this.getTotalSalesButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(228, 175);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 15;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // highestSaleDescriptionLabel
            // 
            this.highestSaleDescriptionLabel.AutoSize = true;
            this.highestSaleDescriptionLabel.Location = new System.Drawing.Point(189, 36);
            this.highestSaleDescriptionLabel.Name = "highestSaleDescriptionLabel";
            this.highestSaleDescriptionLabel.Size = new System.Drawing.Size(70, 13);
            this.highestSaleDescriptionLabel.TabIndex = 16;
            this.highestSaleDescriptionLabel.Text = "Highest Sale:";
            // 
            // lowestSalesDescriptionLabel
            // 
            this.lowestSalesDescriptionLabel.AutoSize = true;
            this.lowestSalesDescriptionLabel.Location = new System.Drawing.Point(191, 78);
            this.lowestSalesDescriptionLabel.Name = "lowestSalesDescriptionLabel";
            this.lowestSalesDescriptionLabel.Size = new System.Drawing.Size(68, 13);
            this.lowestSalesDescriptionLabel.TabIndex = 17;
            this.lowestSalesDescriptionLabel.Text = "Lowest Sale:";
            // 
            // averageSalesDescriptionLabel
            // 
            this.averageSalesDescriptionLabel.AutoSize = true;
            this.averageSalesDescriptionLabel.Location = new System.Drawing.Point(190, 117);
            this.averageSalesDescriptionLabel.Name = "averageSalesDescriptionLabel";
            this.averageSalesDescriptionLabel.Size = new System.Drawing.Size(79, 13);
            this.averageSalesDescriptionLabel.TabIndex = 18;
            this.averageSalesDescriptionLabel.Text = "Average Sales:";
            // 
            // highestSaleLabel
            // 
            this.highestSaleLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.highestSaleLabel.Location = new System.Drawing.Point(285, 36);
            this.highestSaleLabel.Name = "highestSaleLabel";
            this.highestSaleLabel.Size = new System.Drawing.Size(100, 23);
            this.highestSaleLabel.TabIndex = 19;
            this.highestSaleLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lowestSalesLabel
            // 
            this.lowestSalesLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lowestSalesLabel.Location = new System.Drawing.Point(285, 78);
            this.lowestSalesLabel.Name = "lowestSalesLabel";
            this.lowestSalesLabel.Size = new System.Drawing.Size(100, 23);
            this.lowestSalesLabel.TabIndex = 20;
            this.lowestSalesLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // averageSalesLabel
            // 
            this.averageSalesLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.averageSalesLabel.Location = new System.Drawing.Point(285, 117);
            this.averageSalesLabel.Name = "averageSalesLabel";
            this.averageSalesLabel.Size = new System.Drawing.Size(100, 23);
            this.averageSalesLabel.TabIndex = 21;
            this.averageSalesLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(459, 246);
            this.Controls.Add(this.averageSalesLabel);
            this.Controls.Add(this.lowestSalesLabel);
            this.Controls.Add(this.highestSaleLabel);
            this.Controls.Add(this.averageSalesDescriptionLabel);
            this.Controls.Add(this.lowestSalesDescriptionLabel);
            this.Controls.Add(this.highestSaleDescriptionLabel);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.getTotalSalesButton);
            this.Controls.Add(this.totalSalesListBox);
            this.Controls.Add(this.testScoresDescriptionLabel);
            this.Name = "Form1";
            this.Text = "Total Sales";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label testScoresDescriptionLabel;
        private System.Windows.Forms.ListBox totalSalesListBox;
        private System.Windows.Forms.Button getTotalSalesButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label highestSaleDescriptionLabel;
        private System.Windows.Forms.Label lowestSalesDescriptionLabel;
        private System.Windows.Forms.Label averageSalesDescriptionLabel;
        private System.Windows.Forms.Label highestSaleLabel;
        private System.Windows.Forms.Label lowestSalesLabel;
        private System.Windows.Forms.Label averageSalesLabel;
    }
}

