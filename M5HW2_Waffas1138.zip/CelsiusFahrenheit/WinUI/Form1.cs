﻿/**
* 3/30/21
* CSC 153
* Travis Bivins
* This program uses a lsitbox as a table to convert Celsius to Fahrenheit and show the user both values
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void DisplayTableButton_Click(object sender, EventArgs e)
        {
            //Sets the Min value to 0 so Celsius will start at 0 while also setting the Max value to 21
            // so the for loop will be able to show you 0-20 Celsius to Fahrenheit.
            const int MIN_celsius = 0;
            const int MAX_celsius = 21;
            //sets fahrenheit as a decimal since it needs the decimal value and helps with the calclations
            decimal fahrenheit;
            for (int i = MIN_celsius; i < MAX_celsius; i++)
            {

                //Does the calculation to convert to Fahrenheit as well as displays the 
                //corresponding values from Celsius to Fahrenheit for the user.
                fahrenheit = (9m / 5) * i + 32;
                FtoCtable.Items.Add(i + " degrees celsius is equal to " + fahrenheit + " degrees fahrenheit");
            }
        }

        private void ClearButton_Click(object sender, EventArgs e)
        {
            // Clears the table to redo the program with exiting it
            FtoCtable.Items.Clear();
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            //Exits the program when clicked
            this.Close();
        }
    }
}
