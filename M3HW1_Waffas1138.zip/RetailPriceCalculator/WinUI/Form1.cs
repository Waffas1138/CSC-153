﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinUI
{
    public partial class TotalForm : Form
    {
        public TotalForm()
        {
            InitializeComponent();
        }

        private void Calcbutton_Click(object sender, EventArgs e)
        {
            double wholesale;
            double markup;

            if (double.TryParse(RetailTextBox.Text, out wholesale) && double.TryParse(MarkIpTextBox.Text, out markup))
            {
                
                double retailPrice;
                retailPrice = CalculateRetail(wholesale, markup);
                TotaltextBox.Text = retailPrice.ToString("C");
            }
            else
                MessageBox.Show("Please enter a valid number.");
        }
        public double CalculateRetail(double wholesale, double markup)
        {
            double markupPercent = markup / 100;
            double retailPrice;

            retailPrice = wholesale + (wholesale * markupPercent);
            return retailPrice;
        }

        private void Exitbutton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
