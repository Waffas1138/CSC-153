﻿
namespace WinUI
{
    partial class TotalForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Calcbutton = new System.Windows.Forms.Button();
            this.RetailTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Retaillabel = new System.Windows.Forms.Label();
            this.MarkupLabel = new System.Windows.Forms.Label();
            this.TotalLabel = new System.Windows.Forms.Label();
            this.Exitbutton = new System.Windows.Forms.Button();
            this.MarkIpTextBox = new System.Windows.Forms.TextBox();
            this.TotaltextBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // Calcbutton
            // 
            this.Calcbutton.Location = new System.Drawing.Point(464, 80);
            this.Calcbutton.Name = "Calcbutton";
            this.Calcbutton.Size = new System.Drawing.Size(75, 53);
            this.Calcbutton.TabIndex = 0;
            this.Calcbutton.Text = "Calculate Total";
            this.Calcbutton.UseVisualStyleBackColor = true;
            this.Calcbutton.Click += new System.EventHandler(this.Calcbutton_Click);
            // 
            // RetailTextBox
            // 
            this.RetailTextBox.Location = new System.Drawing.Point(190, 97);
            this.RetailTextBox.Name = "RetailTextBox";
            this.RetailTextBox.Size = new System.Drawing.Size(82, 20);
            this.RetailTextBox.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(362, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Retail Price Calculator ";
            // 
            // Retaillabel
            // 
            this.Retaillabel.AutoSize = true;
            this.Retaillabel.Location = new System.Drawing.Point(33, 100);
            this.Retaillabel.Name = "Retaillabel";
            this.Retaillabel.Size = new System.Drawing.Size(151, 13);
            this.Retaillabel.TabIndex = 3;
            this.Retaillabel.Text = "What is your wholesale price?:";
            // 
            // MarkupLabel
            // 
            this.MarkupLabel.AutoSize = true;
            this.MarkupLabel.Location = new System.Drawing.Point(58, 201);
            this.MarkupLabel.Name = "MarkupLabel";
            this.MarkupLabel.Size = new System.Drawing.Size(170, 13);
            this.MarkupLabel.TabIndex = 4;
            this.MarkupLabel.Text = "What is your markup percentage?:";
            // 
            // TotalLabel
            // 
            this.TotalLabel.AutoSize = true;
            this.TotalLabel.Location = new System.Drawing.Point(96, 262);
            this.TotalLabel.Name = "TotalLabel";
            this.TotalLabel.Size = new System.Drawing.Size(115, 13);
            this.TotalLabel.TabIndex = 5;
            this.TotalLabel.Text = "Here is your total price:";
            // 
            // Exitbutton
            // 
            this.Exitbutton.Location = new System.Drawing.Point(464, 176);
            this.Exitbutton.Name = "Exitbutton";
            this.Exitbutton.Size = new System.Drawing.Size(75, 49);
            this.Exitbutton.TabIndex = 7;
            this.Exitbutton.Text = "Exit Program";
            this.Exitbutton.UseVisualStyleBackColor = true;
            this.Exitbutton.Click += new System.EventHandler(this.Exitbutton_Click);
            // 
            // MarkIpTextBox
            // 
            this.MarkIpTextBox.Location = new System.Drawing.Point(234, 198);
            this.MarkIpTextBox.Name = "MarkIpTextBox";
            this.MarkIpTextBox.Size = new System.Drawing.Size(82, 20);
            this.MarkIpTextBox.TabIndex = 9;
            // 
            // TotaltextBox
            // 
            this.TotaltextBox.Location = new System.Drawing.Point(234, 262);
            this.TotaltextBox.Name = "TotaltextBox";
            this.TotaltextBox.Size = new System.Drawing.Size(82, 20);
            this.TotaltextBox.TabIndex = 10;
            // 
            // TotalForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.TotaltextBox);
            this.Controls.Add(this.MarkIpTextBox);
            this.Controls.Add(this.Exitbutton);
            this.Controls.Add(this.TotalLabel);
            this.Controls.Add(this.MarkupLabel);
            this.Controls.Add(this.Retaillabel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.RetailTextBox);
            this.Controls.Add(this.Calcbutton);
            this.Name = "TotalForm";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Calcbutton;
        private System.Windows.Forms.TextBox RetailTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label Retaillabel;
        private System.Windows.Forms.Label MarkupLabel;
        private System.Windows.Forms.Label TotalLabel;
        private System.Windows.Forms.Button Exitbutton;
        private System.Windows.Forms.TextBox MarkIpTextBox;
        private System.Windows.Forms.TextBox TotaltextBox;
    }
}

