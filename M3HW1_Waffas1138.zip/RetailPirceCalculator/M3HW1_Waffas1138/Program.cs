﻿/**
 * 2/13/21
 * CSC 153
 * Travis Bivins
 * This program will let you enter the item's wholesale cost as well as the markup 
 * percentage then afterwards it will display the item's reatil pirce for you
 */

using System;

namespace M3HW1_Waffas1138
{
    class Program
    {
        static public void Main(string[] args)
        {
            // Nice intro message to the user telling what this will be used for
            Console.WriteLine("This will calculate the toal value for any item you wish.");
            CalculateRetail(); // This calls the method CalculteRetail which has all my functions and calculations 
            Console.WriteLine("Thank you for using this program.");
            Console.ReadLine();
        }

        

        static public void CalculateRetail()
        {
            // This will be used to find out what the users Wholesale value is for their item
            Console.WriteLine("What is the item's wholesale cost?: $");
            double wholeSale = Convert.ToDouble(Console.ReadLine()); // used to convert string to a double

            // This is used to get the users markup percentage as well for the item of their picking
            Console.WriteLine("What is the item's markup percentage as well? Please enter in decimal format: $");
            double markUp = Convert.ToDouble(Console.ReadLine());// used to convert string to a double
            
            // This will calculate the total cost for their item by dividing wholeSale by
            // markUp since it is a whole number by a decimal
            double totalRetail = wholeSale / markUp;

            // This is the final line which will show the user their total value for their item of choosing
            Console.WriteLine("The total value of your item is : $" + totalRetail);
        }
    }
}
