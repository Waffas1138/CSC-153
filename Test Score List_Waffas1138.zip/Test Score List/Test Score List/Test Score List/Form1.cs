﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Test_Score_List
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        
        private void getScoresButton_Click(object sender, EventArgs e)
        {
            // hard coded the test scores into a list to get the averages
            List<int> scores = new List<int>() {98,87,65,54,88,75,99,92,85,78,81,69,72,89,75,72,
                                                90,100,61,84};
            
            //creates the methods for the average, and how many numbers are above or below the average and displays them
            DisplayScores(scores);

            double average = GetAverage(scores);

            int aboveAvg = AboveAverage(scores, average);

            int belowAvg = BelowAverage(scores, average);

            DisplayAverages(average, aboveAvg, belowAvg);

            
        }

        private void DisplayAverages(double average, int aboveAvg, int belowAvg)
        {
            // displays the test scores here in the labels after converting to string
            averageLabel.Text = average.ToString();
            aboveAverageLabel.Text = aboveAvg.ToString();
            belowAverageLabel.Text = belowAvg.ToString();
        }

        private int AboveAverage(List<int> scores, double average)
        {
            // method for getting the scores that are above the average test score and displaying how many there are above it
            int count = 0;

            for (int index = 0; index < scores.Count; index++)
            {
                if(scores[index] > average)
                {
                    count++;
                }
            }
            return count;
        }
        private int BelowAverage(List<int> scores, double average)
        {
            // method for getting the scores that are below the average test score and displaying how many there are below it
            int count = 0;

            for (int index = 0; index < scores.Count; index++)
            {
                if (scores[index] < average)
                {
                    count++;
                }
            }
            return count;
        }
        private double GetAverage(List<int> scores)
        {
            //method that is used to add up all the test scores and then divide it by how many there were to get the average test scoree
            int total = 0;
            for (int index = 0; index < scores.Count; index++)
            {
                total += scores[index];
            }

            return total / scores.Count;
        }

        private void DisplayScores(List<int> scores)
        {
            //disaplys all the test scores into the listbox for viewing
            for(int index = 0; index < scores.Count; index++)
            {
                scores[index]++;
                testScoresListBox.Items.Add(scores[index]);
            }
        }
        private void exitButton_Click(object sender, EventArgs e)
        {
            //Closes the program when clicked
            this.Close();
        }
    }
}
