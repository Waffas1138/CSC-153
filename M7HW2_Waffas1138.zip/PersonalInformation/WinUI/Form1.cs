﻿/**
* 4/30/21
* CSC 153
* Travis Bivins
* This program will allow the user to input personal information and display it 
* as well as entering it multiple time times for other people they have
*/
using System;
using System.Collections.Generic;
/**
* 5/8/21
* CSC 153
* Travis Bivins
* This program holds multiple values of a users personal information and store it into a list for them to view
*/
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PersonalInfoLibrary;

namespace WinUI
{
    public partial class Form1 : Form
    {
        //creates our list to hold al lof our objects in
        List<PersonalInformation> InformationList = new List<PersonalInformation>();
        public Form1()
        {
            InitializeComponent();
        }
        PersonalInformation peronsalinformation;
        private void GetPersonalInformation(PersonalInformation Info)
        {

            // sets the values up and primes them to be entered by the user when needed
            int age;
            Info.Name = nameText.Text;
            Info.Address = addressText.Text;
            long phoneNum;


            //try parse set up to make sure that numbers are entered for the age and phone numbers
            if(int.TryParse(ageText.Text, out age) && long.TryParse(phoneNumText.Text, out phoneNum))
            {
                Info.Age = age;
                Info.PhoneNum = phoneNum;
            }
            else
            {
                MessageBox.Show("Please enter a valid age and phone number.");
            }
        }
        private void enterInfoButton_Click(object sender, EventArgs e)
        {
            // this sets up the lists and assigns the values to the correct places they need to be
            PersonalInformation myInfo = new PersonalInformation();

            GetPersonalInformation(myInfo);
            InformationList.Add(myInfo);
            personalInfoList.Items.Add(myInfo.Name);

            //clears the textbox once they are entered into the listbox
            nameText.Clear();
            addressText.Clear();
            ageText.Clear();
            phoneNumText.Clear();
            //Sets the foucs back to the name textbox
            nameText.Focus();
        }

        private void displayButton_Click(object sender, EventArgs e)
        {
            int index = personalInfoList.SelectedIndex;
            //Creates the index for our listbox so it can grow as long as it needs to be
            // Also gives each of the other variables a messagebox to show the values entered for the person
            MessageBox.Show(InformationList[index].Address.ToString()); 
            MessageBox.Show(InformationList[index].Age.ToString()); 
            MessageBox.Show(InformationList[index].PhoneNum.ToString());
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Closes the program
            this.Close();
        }
    }
}
