﻿
namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.nameText = new System.Windows.Forms.TextBox();
            this.addressText = new System.Windows.Forms.TextBox();
            this.phoneNumText = new System.Windows.Forms.TextBox();
            this.ageText = new System.Windows.Forms.TextBox();
            this.nameLabel = new System.Windows.Forms.Label();
            this.addressLabel = new System.Windows.Forms.Label();
            this.ageLabel = new System.Windows.Forms.Label();
            this.phoneNumLabel = new System.Windows.Forms.Label();
            this.enterInfoButton = new System.Windows.Forms.Button();
            this.displayButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.personalInfoList = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // nameText
            // 
            this.nameText.Location = new System.Drawing.Point(114, 41);
            this.nameText.Name = "nameText";
            this.nameText.Size = new System.Drawing.Size(170, 20);
            this.nameText.TabIndex = 0;
            // 
            // addressText
            // 
            this.addressText.Location = new System.Drawing.Point(114, 101);
            this.addressText.Name = "addressText";
            this.addressText.Size = new System.Drawing.Size(170, 20);
            this.addressText.TabIndex = 1;
            // 
            // phoneNumText
            // 
            this.phoneNumText.Location = new System.Drawing.Point(114, 223);
            this.phoneNumText.Name = "phoneNumText";
            this.phoneNumText.Size = new System.Drawing.Size(170, 20);
            this.phoneNumText.TabIndex = 2;
            // 
            // ageText
            // 
            this.ageText.Location = new System.Drawing.Point(114, 159);
            this.ageText.Name = "ageText";
            this.ageText.Size = new System.Drawing.Size(170, 20);
            this.ageText.TabIndex = 3;
            // 
            // nameLabel
            // 
            this.nameLabel.AutoSize = true;
            this.nameLabel.Location = new System.Drawing.Point(43, 44);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(35, 13);
            this.nameLabel.TabIndex = 4;
            this.nameLabel.Text = "Name";
            // 
            // addressLabel
            // 
            this.addressLabel.AutoSize = true;
            this.addressLabel.Location = new System.Drawing.Point(43, 104);
            this.addressLabel.Name = "addressLabel";
            this.addressLabel.Size = new System.Drawing.Size(45, 13);
            this.addressLabel.TabIndex = 5;
            this.addressLabel.Text = "Address";
            // 
            // ageLabel
            // 
            this.ageLabel.AutoSize = true;
            this.ageLabel.Location = new System.Drawing.Point(43, 162);
            this.ageLabel.Name = "ageLabel";
            this.ageLabel.Size = new System.Drawing.Size(26, 13);
            this.ageLabel.TabIndex = 6;
            this.ageLabel.Text = "Age";
            // 
            // phoneNumLabel
            // 
            this.phoneNumLabel.AutoSize = true;
            this.phoneNumLabel.Location = new System.Drawing.Point(30, 226);
            this.phoneNumLabel.Name = "phoneNumLabel";
            this.phoneNumLabel.Size = new System.Drawing.Size(78, 13);
            this.phoneNumLabel.TabIndex = 7;
            this.phoneNumLabel.Text = "Phone Number";
            // 
            // enterInfoButton
            // 
            this.enterInfoButton.Location = new System.Drawing.Point(46, 296);
            this.enterInfoButton.Name = "enterInfoButton";
            this.enterInfoButton.Size = new System.Drawing.Size(156, 42);
            this.enterInfoButton.TabIndex = 8;
            this.enterInfoButton.Text = "Enter Information";
            this.enterInfoButton.UseVisualStyleBackColor = true;
            this.enterInfoButton.Click += new System.EventHandler(this.enterInfoButton_Click);
            // 
            // displayButton
            // 
            this.displayButton.Location = new System.Drawing.Point(268, 296);
            this.displayButton.Name = "displayButton";
            this.displayButton.Size = new System.Drawing.Size(156, 42);
            this.displayButton.TabIndex = 9;
            this.displayButton.Text = "Display Information";
            this.displayButton.UseVisualStyleBackColor = true;
            this.displayButton.Click += new System.EventHandler(this.displayButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(472, 296);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(156, 42);
            this.exitButton.TabIndex = 10;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // personalInfoList
            // 
            this.personalInfoList.FormattingEnabled = true;
            this.personalInfoList.Location = new System.Drawing.Point(418, 45);
            this.personalInfoList.Name = "personalInfoList";
            this.personalInfoList.Size = new System.Drawing.Size(328, 212);
            this.personalInfoList.TabIndex = 11;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(786, 367);
            this.Controls.Add(this.personalInfoList);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.displayButton);
            this.Controls.Add(this.enterInfoButton);
            this.Controls.Add(this.phoneNumLabel);
            this.Controls.Add(this.ageLabel);
            this.Controls.Add(this.addressLabel);
            this.Controls.Add(this.nameLabel);
            this.Controls.Add(this.ageText);
            this.Controls.Add(this.phoneNumText);
            this.Controls.Add(this.addressText);
            this.Controls.Add(this.nameText);
            this.Name = "Form1";
            this.Text = "Personal Information";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox nameText;
        private System.Windows.Forms.TextBox addressText;
        private System.Windows.Forms.TextBox phoneNumText;
        private System.Windows.Forms.TextBox ageText;
        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.Label addressLabel;
        private System.Windows.Forms.Label ageLabel;
        private System.Windows.Forms.Label phoneNumLabel;
        private System.Windows.Forms.Button enterInfoButton;
        private System.Windows.Forms.Button displayButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.ListBox personalInfoList;
    }
}

