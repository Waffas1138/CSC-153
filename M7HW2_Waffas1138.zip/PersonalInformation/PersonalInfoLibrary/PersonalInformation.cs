﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonalInfoLibrary
{
    public class PersonalInformation
    {
        //Constructor for our methods
        public PersonalInformation()
        {
            Name = "";
            Address = "";
            Age = 0;
            PhoneNum = 0;
        }

        //Followed by the properties for Name, Address, Age and Phone Numbers
        public string Name { get; set; }
        public string Address { get; set; }
        public int Age { get; set; }
        public long PhoneNum { get; set; }
    }
}
